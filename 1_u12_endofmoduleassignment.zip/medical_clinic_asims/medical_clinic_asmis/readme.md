# DESCRIPTION
Created on Python, Django, and SQLite.
This project is based on the UML diagrams submitted in the Individual Essay for LCYS_PCOM7E August 2021. The project utilizes various security techniques including AAA (authentication, authorization, and auditing) and securely storing passwords using SHA256 algorithm and hash salt. Use the ASMIS Django Administration site to 

- Login as an Administrator (superuser account)
- Create staff users (IT Admins, Ops Admins, Doctors) and manage their view to the Admin portal
- Manage patient appointments
- Change user account passwords

# 1) Open Terminal within Codio via Tools > Terminal

# 2) Install and Execute

```
sudo apt-get install python3 
sudo apt install sqlitebrowser
pip3 install django
```

# 3) Create Administrator account to manage admins/doctors/patients accounts and permissions and appointment bookings
```
cd medical_clinic_asmis/
python3 manage.py createsuperuser
```

# 4) Start Server
```
python3 manage.py runserver 0.0.0.0:8000
```

# 5) Access Django Administration App using Box URL Django Admin or connect to https://teacher-survive-8000.codio-box.uk/admin via browser. Login with superuser account.

# 6) Go through medical_clinic_asmis/test_cases.md