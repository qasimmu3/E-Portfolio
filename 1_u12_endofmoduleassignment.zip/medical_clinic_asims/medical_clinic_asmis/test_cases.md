# Test SuperUser Account
Username: admin
Password: B9iXLUmvy4u5YbP

# Test Cases for Django Administration Site
https://www.softwaretestinghelp.com/login-page-test-cases/

| Case # | Functional Test Case                                                                               | Result Positive / Negative |
|--------|----------------------------------------------------------------------------------------------------|----------------------------|
| 1      | Verify if a user will be able to login with a valid username and valid password.                   | POSITIVE                   |
| 2      | Verify if a user cannot login with a valid username and an invalid password.                       | POSITIVE                   |
| 3      | Verify the login page for both, when the field is blank and Submit button is clicked.              | POSITIVE                   |
| 4      | Verify the messages for invalid login.                                                             | POSITIVE                   |
| 5      | Verify if the data in password field is either visible as asterisk or bullet signs.                | POSITIVE                   |
| 6      | Verify superuser can create appointments for doctors and the appointments are visible for doctors. | POSITIVE                   |
| 7      | Verify newly created account can login with a valid username and valid password.                   | POSITIVE                   |
| 8      | Verify recent actions pane is being update when making a change to an appointment.                 | POSITIVE                   |
| 9      | Verify newly created user is updating database using database browser app (SQLLiteBrowser).        | POSITIVE                   |
| 10     | Verify users within Doctor can login and view only appointments.                                   | POSITIVE                   |
| 11     | Verify users with 'Staff Status' disabled cannot login to admin page.                              | POSITIVE                   |
| 12     | Verify inactive account cannot login to the Admin portal.                                          | POSITIVE                   |