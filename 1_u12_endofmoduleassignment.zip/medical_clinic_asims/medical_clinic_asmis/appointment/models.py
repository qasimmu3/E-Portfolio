from django.db import models
from doctor.models import Doctor
from patient.models import Patient

# Create your models here.
DISEASE = (
    ('Oncological', 'Oncological'),
    ('Obstetric', 'Obstetric'),
    ('Endocrinology', 'Endocrinology'),
    ('Urology', 'Urology'),
    ('Pediatrics', 'Pediatrics'),
    ('Dermatology', 'Dermatology'),
    ('Otorhinolary', 'Otorhinolary'),
)


class Appointment(models.Model):
    doctor = models.ForeignKey(Doctor, on_delete=models.PROTECT)
    patient = models.ForeignKey(Patient, on_delete=models.PROTECT)
    fee = models.DecimalField(default=10.0, decimal_places=2, max_digits=11)
    appointment_time = models.TimeField()
    # disease = models.CharField(choices=DISEASE, max_length=100)
