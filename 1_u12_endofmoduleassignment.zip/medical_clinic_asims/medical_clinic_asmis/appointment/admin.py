from django.contrib import admin

# Register your models here.
from appointment.models import Appointment


class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('doctor', 'patient', 'fee', 'appointment_time')
    list_filter = ('doctor', 'patient')
    readonly_fields = ('fee',)



admin.site.register(Appointment, AppointmentAdmin)
