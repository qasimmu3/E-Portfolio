from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models

DISEASE = (
    ('Oncological', 'Oncological'),
    ('Obstetric', 'Obstetric'),
    ('Endocrinology', 'Endocrinology'),
    ('Urology', 'Urology'),
    ('Pediatrics', 'Pediatrics'),
    ('Dermatology', 'Dermatology'),
    ('Otorhinolary', 'Otorhinolary'),
)


# Create your models here.
class Patient(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField(validators=[MinValueValidator(0), MaxValueValidator(150)])
    height = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(300)])  # Height is measured in centimeters
    weight = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(500)]  # Weight is measured in kilograms
    )
    disease = models.CharField(choices=DISEASE, max_length=100)

    def __str__(self):
        return self.name