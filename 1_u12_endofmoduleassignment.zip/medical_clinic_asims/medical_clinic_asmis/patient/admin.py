from django.contrib import admin

# Register your models here.
from patient.models import Patient


class PatientAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'height', 'weight', 'disease')
    list_filter = ('name', 'disease')
    search_fields = ('name', 'disease')


admin.site.register(Patient, PatientAdmin)
