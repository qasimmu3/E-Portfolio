from django.contrib import admin

# Register your models here.
from doctor.models import Doctor


class DoctorAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'height', 'weight', 'specialize', 'work_start', 'work_end')
    list_filter = ('name', 'specialize', 'work_start')
    search_fields = ('name',)


admin.site.register(Doctor, DoctorAdmin)
