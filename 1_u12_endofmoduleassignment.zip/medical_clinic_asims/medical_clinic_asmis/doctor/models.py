from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

SPECIALIZE = (
    ('Oncological', 'Oncological'),
    ('Obstetric', 'Obstetric'),
    ('Endocrinology', 'Endocrinology'),
    ('Urology', 'Urology'),
    ('Pediatrics', 'Pediatrics'),
    ('Dermatology', 'Dermatology'),
    ('Otorhinolary', 'Otorhinolary'),
)


# Create your models here.
class Doctor(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField(validators=[MinValueValidator(0), MaxValueValidator(150)])
    height = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(300)])  # Height is measured in centimeters
    weight = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(500)]  # Weight is measured in kilograms
    )
    specialize = models.CharField(choices=SPECIALIZE, max_length=100)
    work_start = models.TimeField()
    work_end = models.TimeField()

    def __str__(self):
        return self.name
